# npm install -g remixd
remixd -s ./contracts/ --remix-ide https://remix.ethereum.org/