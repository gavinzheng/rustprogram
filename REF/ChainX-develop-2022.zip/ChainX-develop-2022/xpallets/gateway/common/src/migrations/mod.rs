// Copyright 2019-2022 ChainX Project Authors. Licensed under GPL-3.0.

//! All migrations of this pallet.

pub mod taproot;
