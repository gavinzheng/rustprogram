// Copyright 2019-2022 ChainX Project Authors. Licensed under GPL-3.0.

//! ChainX CLI

fn main() -> cli::Result<()> {
    cli::run()
}
