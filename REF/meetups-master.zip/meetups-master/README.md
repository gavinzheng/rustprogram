# Rust Zürichsee

## Slides

All slides and other materials of the meetups are inside a directory per meetup.

## Upcoming events

Follow the our [Rust Zürichsee Meetup Group](https://www.meetup.com/Rust-Zurich/) and the [Mozilla CH Meetup](https://www.meetup.com/Mozilla-Meetup-Switzerland/).
