"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function ethScanner() {
    var client = {};
    /*
     * Get total value of all assets in account.
     * NFT value determined by LooksRare floor. ERC20's determined by coingecko API
     */
    client.evaluateAccounts = function (address) { };
    return client;
}
exports.default = ethScanner;
//# sourceMappingURL=index.js.map