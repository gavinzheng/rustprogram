"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleError = void 0;
var handleError = function (error) { return error; };
exports.handleError = handleError;
//# sourceMappingURL=errorResponse.js.map