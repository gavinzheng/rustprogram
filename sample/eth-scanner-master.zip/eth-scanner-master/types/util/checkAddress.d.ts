export default function checkAddress(address: string | Array<string>): Promise<void>;
