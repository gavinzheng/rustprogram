"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function queryBuilder(filters) {
    if (!filters.token) {
        throw new Error("Token not provided");
    }
}
exports.default = queryBuilder;
//# sourceMappingURL=queryBuilder.js.map