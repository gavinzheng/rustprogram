interface QueryFilters {
    stuff: any;
}
export default function queryBuilder(filters: any): void;
export { QueryFilters };
