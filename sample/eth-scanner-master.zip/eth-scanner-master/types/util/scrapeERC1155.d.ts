export default function scrapeERC1155(): Promise<void>;
