export declare const handleError: (error: Error) => Error;
