export default function getAllAssets(address: string, etherscanKey: string): void;
