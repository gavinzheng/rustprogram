"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/* eslint-disable import/no-unresolved */
/* eslint-disable import/extensions */
var checkAddress_1 = __importDefault(require("../util/checkAddress"));
function evaluateAccounts(address) {
    (0, checkAddress_1.default)(address);
}
exports.default = evaluateAccounts;
//# sourceMappingURL=evaluateAccounts.js.map