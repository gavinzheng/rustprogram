export default function testAPIs(): Promise<void>;
