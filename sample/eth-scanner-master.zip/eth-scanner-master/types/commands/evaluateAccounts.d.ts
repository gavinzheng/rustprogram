export default function evaluateAccounts(address: string | Array<string>): void;
