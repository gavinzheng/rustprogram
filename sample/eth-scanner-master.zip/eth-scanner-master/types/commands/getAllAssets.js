"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function getAllAssets(address, etherscanKey) { }
exports.default = getAllAssets;
//# sourceMappingURL=getAllAssets.js.map