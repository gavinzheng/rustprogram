"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function evaluateAccount() {
}
exports.default = evaluateAccount;
//# sourceMappingURL=evaluateAccount.js.map