export default function evaluateAccount(): void;
