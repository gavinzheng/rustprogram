export default function ethScanner(): any;
