# eth-scanner

The purpose of this library is to get token balances (ERC20, ERC721, and ERC1155) for an ethereum address with functionality to get the exchange rates for each token as well. The goal was to do it without the need for an API key but have an option for a user supplied one.

NOTE: This library is incomplete and I may or may not come back and complete it. I would love to, but i just dont have time at the moment. If I do, I will open a trello board to manage it and I will post the link here.
