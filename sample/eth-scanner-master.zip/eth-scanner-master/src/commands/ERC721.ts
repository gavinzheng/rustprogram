import { ChecksumAddresses, ERC721Balances } from '../types';

export default async function ERC721(
    account: ChecksumAddresses,
    prices?: boolean
): Promise<ERC721Balances> {}
