import { AllBalances, ChecksumAddresses } from '../types';

export default async function evaluateAccounts(
    account: ChecksumAddresses,
    prices?: boolean
): Promise<AllBalances> {}
