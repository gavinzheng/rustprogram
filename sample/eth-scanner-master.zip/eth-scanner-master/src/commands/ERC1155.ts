import { ChecksumAddresses, ERC1155Balances } from '../types';

export default async function ERC1155(
    account: ChecksumAddresses,
    prices?: boolean
): Promise<ERC1155Balances> {}
