import abi from './abi';
const BalanceScanner = {
    address: '0x08A8fDBddc160A7d5b957256b903dCAb1aE512C5',
    abi: abi,
};
export default BalanceScanner;
