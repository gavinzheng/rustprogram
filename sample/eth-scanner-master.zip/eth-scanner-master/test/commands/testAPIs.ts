import testAPIs from "../../src/commands/testAPI";
describe("API Test", () => {
  it("etherscan", async () => {
    //await testAPIs();
  });
});
