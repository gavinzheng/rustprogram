export default function currentTime(): number {
    return Math.floor(Date.now() / 1000);
}
