export const coinGeckoBaseUrl = 'https://api.coingecko.com/api/v3/';
