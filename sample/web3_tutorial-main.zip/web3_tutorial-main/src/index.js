import React from 'react';
import ReactDOM from 'react-dom';
import { Gege } from './first/Greet_Tinz';
import './index.css';

ReactDOM.render(<Gege />, document.getElementById("gege"));