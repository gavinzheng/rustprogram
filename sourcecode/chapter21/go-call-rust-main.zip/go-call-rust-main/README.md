To run this project, you will need to:
in the rust-cli-code directory, run the following command:

```bash

cargo build --release 

```

then you can run the binary with the following command:

```bash

go run main.go

```
And there you go, you are calling a rust binary from go!