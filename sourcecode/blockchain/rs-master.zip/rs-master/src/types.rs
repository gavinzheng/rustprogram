/// Type alias for `[u8; 32]`, which is a 256-bit key
pub type AesKey = [u8; 32];
