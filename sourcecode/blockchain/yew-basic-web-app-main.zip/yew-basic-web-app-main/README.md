# WebAssembly Rust web front-end basic Yew example

This repository is a companion to my tutorial on basic examples show casing various elements on the Yew framework. The examples show use of events, element references, components, function components, and some of the component life cycle.

The tutorial can be found on my blog here: [WebAssembly Rust front-end with Yew: how to P1](https://tms-dev-blog.com/webassembly-rust-front-end-with-yew-how-to-p1/)

