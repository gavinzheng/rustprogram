# Rust-link-list

本书仓库为《Learn Rust With Entirely Too Many Linked Lists》的学习源码

原书地址：https://rust-unofficial.github.io/too-many-lists/index.html

视频地址:https://www.bilibili.com/video/BV1eb4y1Q7FA

更多Rust视频教材请B站搜索“令狐一冲”

