Keystore (and session key management) for ed25519 based chains like Polkadot.

License: GPL-3.0-or-later WITH Classpath-exception-2.0