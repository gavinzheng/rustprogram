Generic Transaction Pool

The pool is based on dependency graph between transactions
and their priority.
The pool is able to return an iterator that traverses transaction
graph in the correct order taking into account priorities and dependencies.

License: GPL-3.0-or-later WITH Classpath-exception-2.0