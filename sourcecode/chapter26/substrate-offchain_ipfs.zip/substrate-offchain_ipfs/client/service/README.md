Substrate service. Starts a thread that spins up the network, client, and extrinsic pool.
Manages communication between them.

License: GPL-3.0-or-later WITH Classpath-exception-2.0