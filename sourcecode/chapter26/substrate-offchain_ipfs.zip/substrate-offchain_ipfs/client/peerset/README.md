Peer Set Manager (PSM). Contains the strategy for choosing which nodes the network should be
connected to.

License: GPL-3.0-or-later WITH Classpath-exception-2.0