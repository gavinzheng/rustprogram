Instrumentation implementation for substrate.

This crate is unstable and the API and usage may change.

# Usage

See `sp-tracing` for examples on how to use tracing.

Currently we provide `Log` (default), `Telemetry` variants for `Receiver`

License: GPL-3.0-or-later WITH Classpath-exception-2.0