A set of common definitions that are needed for defining execution engines.

License: GPL-3.0-or-later WITH Classpath-exception-2.0