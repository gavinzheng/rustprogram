This crate provides an implementation of `WasmModule` that is baked by wasmi.

License: GPL-3.0-or-later WITH Classpath-exception-2.0