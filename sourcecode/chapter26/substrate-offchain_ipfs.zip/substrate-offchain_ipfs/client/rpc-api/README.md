Substrate RPC interfaces.

A collection of RPC methods and subscriptions supported by all substrate clients.

License: GPL-3.0-or-later WITH Classpath-exception-2.0