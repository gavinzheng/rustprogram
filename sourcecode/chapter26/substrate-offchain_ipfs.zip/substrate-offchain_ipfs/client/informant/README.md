Console informant. Prints sync progress and block events. Runs on the calling thread.

License: GPL-3.0-or-later WITH Classpath-exception-2.0