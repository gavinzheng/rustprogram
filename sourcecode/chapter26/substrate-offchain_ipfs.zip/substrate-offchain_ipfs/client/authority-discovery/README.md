Substrate authority discovery.

This crate enables Substrate authorities to discover and directly connect to
other authorities. It is split into two components the [`Worker`] and the
[`Service`].

See [`Worker`] and [`Service`] for more documentation.

License: GPL-3.0-or-later WITH Classpath-exception-2.0