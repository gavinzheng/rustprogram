Slots functionality for Substrate.

Some consensus algorithms have a concept of *slots*, which are intervals in
time during which certain events can and/or must occur.  This crate
provides generic functionality for slots.

License: GPL-3.0-or-later WITH Classpath-exception-2.0