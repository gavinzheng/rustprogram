Generic utilities for epoch-based consensus engines.

License: GPL-3.0-or-later WITH Classpath-exception-2.0