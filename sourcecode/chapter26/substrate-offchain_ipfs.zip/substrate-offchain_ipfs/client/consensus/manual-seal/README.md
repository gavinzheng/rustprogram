A manual sealing engine: the engine listens for rpc calls to seal blocks and create forks.
This is suitable for a testing environment.

License: GPL-3.0-or-later WITH Classpath-exception-2.0