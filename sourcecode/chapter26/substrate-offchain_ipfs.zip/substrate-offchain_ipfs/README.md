# offchain-ipfs fork of substrate

See commit [2f565db0441] for the offchain-ipfs work and the [documentation][book] ([repository][book-repo]).
The work in this repository has stalled (see [comment on #5]) but continued on at least the following forks:

- [uggugteam/substrate](https://github.com/uddugteam/substrate/tree/offchain_ipfs)
- [iridium-labs/substrate](https://github.com/iridium-labs/substrate/tree/offchain_ipfs_v3)

[2f565db0441]: https://github.com/rs-ipfs/substrate/commit/2f565db044133cacfdfc166ca9b96594644e34e9
[book]: https://rs-ipfs.github.io/offchain-ipfs-manual/
[book-repo]: https://github.com/rs-ipfs/offchain-ipfs-manual
[comment on #5]: https://github.com/rs-ipfs/substrate/pull/5#issuecomment-956168803
