module.exports = require('@oclif/command')
