Authorship tracking for FRAME runtimes.

This tracks the current author of the block and recent uncles.

License: Apache-2.0