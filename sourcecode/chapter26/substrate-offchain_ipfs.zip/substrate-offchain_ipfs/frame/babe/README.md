Consensus extension module for BABE consensus. Collects on-chain randomness
from VRF outputs and manages epoch transitions.

License: Apache-2.0