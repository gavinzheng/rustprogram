# Authority discovery module.

This module is used by the `client/authority-discovery` to retrieve the
current set of authorities.

License: Apache-2.0