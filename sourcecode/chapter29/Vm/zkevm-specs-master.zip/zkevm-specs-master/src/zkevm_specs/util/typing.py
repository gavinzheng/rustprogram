from typing import NewType

U64 = NewType("U64", int)
U128 = NewType("U128", int)
U160 = NewType("U160", int)
U256 = NewType("U256", int)
