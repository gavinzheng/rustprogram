include!(concat!(env!("OUT_DIR"), "/methods.rs"));
