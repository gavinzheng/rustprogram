fn main() {
    risc0_build::embed_methods();
}
