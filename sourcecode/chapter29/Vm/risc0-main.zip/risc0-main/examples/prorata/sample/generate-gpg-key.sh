#!/bin/sh
gpg --no-default-keyring  --keyring ./auditor.gpg --quick-gen-key audit@example.com
