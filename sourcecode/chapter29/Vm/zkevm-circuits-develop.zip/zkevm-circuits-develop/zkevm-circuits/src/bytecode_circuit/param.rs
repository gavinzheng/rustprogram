pub const HASH_WIDTH: usize = 32;
pub const KECCAK_WIDTH: usize = 3;
pub const PUSH_TABLE_WIDTH: usize = 2;
