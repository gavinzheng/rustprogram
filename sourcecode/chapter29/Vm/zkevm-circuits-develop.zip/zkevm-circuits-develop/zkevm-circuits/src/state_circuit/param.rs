pub(super) const N_LIMBS_RW_COUNTER: usize = 2;
pub(super) const N_LIMBS_ACCOUNT_ADDRESS: usize = 10;
pub(super) const N_LIMBS_ID: usize = 2;
