Source code taken from https://optimistic.etherscan.io/address/0x4200000000000000000000000000000000000006#code
