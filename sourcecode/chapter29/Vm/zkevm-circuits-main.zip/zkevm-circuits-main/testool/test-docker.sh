docker build docker/lllc -t lllc
docker build docker/solc -t solc
cargo test test_docker --features="test-docker"
