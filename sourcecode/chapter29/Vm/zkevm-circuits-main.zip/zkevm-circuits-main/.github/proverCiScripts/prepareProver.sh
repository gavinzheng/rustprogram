#!/bin/bash
#set -e 
#set -x

prnumber=$1
base_dir="/home/ubuntu/CI_Prover_Benches/"
target_dir="$base_dir"PR"$1"
source_dir=$2

mkdir -p $target_dir

