cargo +nightly fuzz run --no-cfg-fuzzing --strip-dead-code --sanitizer none --release deploy_transaction
