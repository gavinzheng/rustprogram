ALTER TABLE transactions ADD COLUMN mempool_preceding_nonce_gaps SMALLINT;
