DROP INDEX l2_to_l1_logs_tx_hash_index;
DROP TABLE l2_to_l1_logs;
