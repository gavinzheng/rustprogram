ALTER TABLE l1_batches DROP COLUMN aux_data_hash;
ALTER TABLE l1_batches DROP COLUMN pass_through_data_hash;
ALTER TABLE l1_batches DROP COLUMN meta_parameters_hash;
