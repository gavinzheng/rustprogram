ALTER TABLE blocks DROP COLUMN l2_to_l1_logs;
ALTER TABLE blocks DROP COLUMN l2_to_l1_messages;
