ALTER TABLE blocks DROP COLUMN IF EXISTS initial_bootloader_heap_content;
