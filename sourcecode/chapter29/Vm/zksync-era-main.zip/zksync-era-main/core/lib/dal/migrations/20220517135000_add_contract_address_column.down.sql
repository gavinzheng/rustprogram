ALTER TABLE transactions DROP COLUMN IF EXISTS contract_address;
