ALTER TABLE transactions DROP COLUMN valid_from;
ALTER TABLE transactions DROP COLUMN valid_until;
