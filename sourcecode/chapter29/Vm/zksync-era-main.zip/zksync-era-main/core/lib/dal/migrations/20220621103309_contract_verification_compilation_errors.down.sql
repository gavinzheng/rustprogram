ALTER TABLE contract_verification_requests
    DROP COLUMN IF EXISTS compilation_errors;
