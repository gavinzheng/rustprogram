DROP TABLE call_traces;
