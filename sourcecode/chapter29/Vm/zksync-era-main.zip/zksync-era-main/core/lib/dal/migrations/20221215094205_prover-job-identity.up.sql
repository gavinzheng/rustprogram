ALTER TABLE prover_jobs
    ADD proccesed_by TEXT;