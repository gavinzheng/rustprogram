ALTER TABLE transactions DROP COLUMN l1_block_number;
