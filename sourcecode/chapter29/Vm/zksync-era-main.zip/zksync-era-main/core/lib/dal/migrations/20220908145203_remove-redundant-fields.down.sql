ALTER TABLE transactions ADD column type TEXT;
ALTER TABLE transactions ADD column fee_token BYTEA;
