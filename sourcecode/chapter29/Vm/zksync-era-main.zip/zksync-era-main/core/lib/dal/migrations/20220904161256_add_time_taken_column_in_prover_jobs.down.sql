ALTER TABLE prover_jobs DROP COLUMN IF EXISTS time_taken;
