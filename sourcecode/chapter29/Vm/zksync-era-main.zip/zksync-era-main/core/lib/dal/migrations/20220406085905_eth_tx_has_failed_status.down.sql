ALTER TABLE eth_txs DROP COLUMN has_failed;
