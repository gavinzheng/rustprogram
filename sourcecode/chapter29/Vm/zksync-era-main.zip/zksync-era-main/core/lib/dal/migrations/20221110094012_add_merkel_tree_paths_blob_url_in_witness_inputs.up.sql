ALTER TABLE witness_inputs ADD COLUMN IF NOT EXISTS merkel_tree_paths_blob_url TEXT;
