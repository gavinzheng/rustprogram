ALTER TABLE blocks DROP COLUMN IF EXISTS ergs_per_pubdata_limit;
