ALTER TABLE prover_jobs
    DROP COLUMN proccesed_by;