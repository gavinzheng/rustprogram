ALTER TABLE transactions ADD COLUMN l1_batch_tx_index INT;
