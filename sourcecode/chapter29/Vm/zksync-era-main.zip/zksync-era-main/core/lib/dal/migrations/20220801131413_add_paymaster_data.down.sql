ALTER TABLE transactions DROP COLUMN IF EXISTS paymaster;
ALTER TABLE transactions DROP COLUMN IF EXISTS paymaster_input;
