ALTER TABLE witness_inputs ADD COLUMN status TEXT NOT NULL;
