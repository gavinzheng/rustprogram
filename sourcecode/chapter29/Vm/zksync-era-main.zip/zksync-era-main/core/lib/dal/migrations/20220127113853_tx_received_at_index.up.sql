CREATE INDEX transactions_received_at_idx ON transactions(received_at);
