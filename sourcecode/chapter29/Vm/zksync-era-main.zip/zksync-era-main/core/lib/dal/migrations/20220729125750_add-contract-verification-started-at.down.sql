ALTER TABLE contract_verification_requests
    DROP COLUMN IF EXISTS processing_started_at;
