DROP INDEX miniblocks_hash;
