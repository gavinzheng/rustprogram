DROP TABLE IF EXISTS gpu_prover_queue;
