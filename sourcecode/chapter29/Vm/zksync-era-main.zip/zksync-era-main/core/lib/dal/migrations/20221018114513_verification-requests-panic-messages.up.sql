ALTER TABLE contract_verification_requests ADD COLUMN panic_message TEXT;
