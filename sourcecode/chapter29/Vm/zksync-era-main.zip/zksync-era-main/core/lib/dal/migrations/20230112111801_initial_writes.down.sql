DROP INDEX initial_writes_l1_batch_number_index;
DROP TABLE initial_writes;
