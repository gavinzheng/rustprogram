DROP INDEX IF EXISTS eth_txs_history_tx_hash_index;
