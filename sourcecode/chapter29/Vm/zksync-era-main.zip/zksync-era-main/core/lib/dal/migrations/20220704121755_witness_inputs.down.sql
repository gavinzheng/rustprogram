DROP TABLE IF EXISTS witness_inputs;
