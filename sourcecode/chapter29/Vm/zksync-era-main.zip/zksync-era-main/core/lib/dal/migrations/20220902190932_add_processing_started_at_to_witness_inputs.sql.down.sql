ALTER TABLE witness_inputs
    DROP COLUMN IF EXISTS processing_started_at;
