ALTER TABLE gpu_prover_queue DROP CONSTRAINT IF EXISTS gpu_prover_unique_idx;
