CREATE INDEX miniblocks_hash ON miniblocks USING hash (hash);
