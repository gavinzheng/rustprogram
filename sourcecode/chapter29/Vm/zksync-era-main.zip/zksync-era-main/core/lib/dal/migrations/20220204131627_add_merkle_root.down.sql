ALTER TABLE blocks DROP COLUMN merkle_root_hash;
