CREATE INDEX ON "eth_txs_history" (eth_tx_id);
