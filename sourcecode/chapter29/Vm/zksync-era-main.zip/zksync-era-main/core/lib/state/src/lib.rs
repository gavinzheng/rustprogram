//! Execution of transaction in zkSync Era

pub mod secondary_storage;
pub mod storage_view;
