# RTIC v2 example for USB communication

As of Spring 2023 RTIC v2 needs rust nightly therefore to run it use

```shell
cargo +nightly run`
```
