extern crate sensehat;

fn main() {
    println!("Hello, world!");
}
