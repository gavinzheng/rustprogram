# rocket-mongo-api

Build a REST API with Rust and MongoDB - Rocket Version

This repository shows the source code for building a REST API with Rust and MongoDB using the Rocket framework.

Article Link

[Article Link](https://dev.to/hackmamba/build-a-rest-api-with-rust-and-mongodb-rocket-version-ah5)
