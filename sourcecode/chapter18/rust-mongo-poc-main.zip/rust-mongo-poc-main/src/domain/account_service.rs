pub struct AccountService{}

impl AccountService {
    pub fn save(account: Account) {
        
    }
}